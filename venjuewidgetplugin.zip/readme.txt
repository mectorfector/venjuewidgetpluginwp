Tags: Venjue, Events, Bookings, Widget
Requires at least: 3
Tested up to: 6.0
Requires PHP: 4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Easily add the Venjue widget to your WordPress website with one-click installation. Customize and configure to your brand identity with ease. See more at Venjue.com

== Installation ==

 * Install plugin
 * Activate the plugin in WordPress > Plugins > Venjue Widget > Activate
 * Go to Settings > Venjue Widget and set up your widget's customizable options
